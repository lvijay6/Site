<?php

echo phpinfo();

?>
